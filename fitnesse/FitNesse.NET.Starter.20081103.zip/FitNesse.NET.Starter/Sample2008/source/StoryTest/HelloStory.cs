﻿using Sample.Domain;
using fit;

namespace Sample.StoryTest {
    public class HelloStory: ColumnFixture {
        public string String1;
        public string String2;
        public string Join { get { return new Hello(String1, String2).Join; }}
    }
}
