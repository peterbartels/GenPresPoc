namespace Sample.Domain {
    public class Hello {
        private readonly string first;
        private readonly string second;

        public Hello(string first, string second) {
            this.first = first;
            this.second = second;
        }

        public string Join { get { return string.Format("{0} {1}", first, second); }}
    }
}
